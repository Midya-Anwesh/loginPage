import apple from '../assets/apple.png';
import google from '../assets/google.png';

export function LoginFormFooter(){
    return (
        <div className='formFooter'>
            <div className="formFooterHeading">
                <p> or </p>
            </div>

            <div className='formFooterLogos'>
                <img src={apple} className='logo'/>
                <img src={google} className='logo'/>
            </div>
        </ div>
    );
}