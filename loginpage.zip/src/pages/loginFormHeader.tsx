import important from '../assets/important.png';

export function LoginFormHeader(){
    return (
        <div className="formHeader">
            <div className='important'>
                <img src={important} className="formHeaderImg"/>
                <p> Important: </p>
            </div>
            <p> Use your own email, not the player's email.</p>
        </div>
    );
}