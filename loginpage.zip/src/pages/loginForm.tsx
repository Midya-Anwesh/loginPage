import { LoginFormHeader } from './loginFormHeader';
import { LoginFormFooter } from './loginFormFooter';

export function LoginForm(){

    return(
        <>

        <div className='loginForm'>

        <LoginFormHeader />

        <form className='loginFormFields'>

            <div className='role'>
                <label htmlFor="roleField" className='roleLabel'> Your role </label>
                <select id="roleField">
                    <option value='parent'> Parent  </option> 
                </select>
            </div>

            <div className='name'>
                <label htmlFor="nameField" className='nameLabel'> Name </label>
                <input type="text" placeholder="Emma White" id="nameField"/>
            </div>
            
            <div className='email'>
                <label htmlFor="emailField" className='emailLabel'> Email </label>
                <input type="text" placeholder="emm.white@gmail.com" id="emailField"/>
            </div>

            <div className='password'>
                <label htmlFor="passwordField" className='passwordLabel'> Password </label>
                    <input type="password" placeholder="password" id="passwordField"/>
            </div>

            <button type='submit' className='loginBtn' style={{color: '#000000'}}> Login </button>
        </form>

        <LoginFormFooter />

        </div>

        </>
    );
}