import { LoginForm } from "./loginForm";
import { LoginAdvisory } from "./loginAdvisory";
import { PageHeader } from "./pageHeader";
import { PlayStoreBanner } from "./playStoreBanner";
import { PricingInfo } from "./priceingInfo";
import { PageFooter } from "../components/pageFooter";

export function LoginPage(){
    return (
        <div className="loginPage">

            <PageHeader />

            <div className="loginDiv">
                <LoginAdvisory />
                <LoginForm />
            </div>

            <PlayStoreBanner />

            <PricingInfo />

            <PageFooter />

        </div>
    )
}