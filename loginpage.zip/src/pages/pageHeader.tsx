import headerLogo from '../assets/headerLogo.png';

export function PageHeader() {
    return (
        <div className='loginHeader'>
            <img src={headerLogo} className='headerLogo'/>
        </div>
    )
}