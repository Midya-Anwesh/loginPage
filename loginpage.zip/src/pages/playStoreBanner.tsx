import playstoreBanner from '../assets/playstoreBanner.png';

export function PlayStoreBanner(){
    return (
        <div className='banner'>
            <img src={playstoreBanner} className='playstoreBanner'/>
        </div>
    )
}