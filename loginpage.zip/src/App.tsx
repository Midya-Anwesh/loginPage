import './App.css'
import './header.css'
import './banner.css'
import './pricingHeader.css'
import './subscriptionsType.css'
import './footer.css'
import { LoginPage } from './pages/loginPage';

function App() {
  return (
    <>
      <LoginPage />
    </>
  )
}

export default App
