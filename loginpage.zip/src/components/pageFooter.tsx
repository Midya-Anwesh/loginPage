export function PageFooter(){
    return (
        <footer className="pageFooter">
            By continuing to use TennisPreneur application, you acknowledge and agree that you have accepted the Terms of Service and have reviewed the Privacy Policy.
        </footer>
    )
}